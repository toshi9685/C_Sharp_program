﻿using System;
// Dictionaryを使うために必要な名前空間の宣言
using System.Collections.Generic;

namespace 形態素解析
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            /*文頭:0
             *接尾辞:1
             *連体詞:2
             *名詞:3
             *助詞:4
             *動詞:5
             *文末:6
            */
            string[] part = { "文頭","接尾辞","連体詞","名詞","助詞","動詞","文末"};

            //setup
            MultiDictionary<string, int> WordDic = new MultiDictionary<string, int>();//単語辞書
            WordDic.Add("こ", 1);
            WordDic.Add("個", 1);
            WordDic.Add("この", 2);
            WordDic.Add("人", 3);
            WordDic.Add("ひと", 3);
            WordDic.Add("ヒト", 3);
            WordDic.Add("一言",3);
            WordDic.Add("ひとこと",3);
            WordDic.Add("ひ", 3);
            WordDic.Add("日", 3);
            WordDic.Add("と", 4);
            WordDic.Add("こと", 3);
            WordDic.Add("事", 3);
            WordDic.Add("で", 4);
            WordDic.Add("で", 5);
            WordDic.Add("元気",3);
            WordDic.Add("になった",5);
            WordDic.Add("に",4);
            WordDic.Add("なった",5);
            WordDic.Add("。",6);
            WordDic.Add("文頭",0);

            int[,] RerationDic = {//連接可能性辞書
                {0,0,1,1,0,1,0},
                {0,0,0,0,0,0,0},
                {0,0,0,1,0,0,0},
                {0,0,0,1,1,1,1},
                {0,0,0,1,0,1,0},
                {0,0,0,1,0,0,0},
                {0,0,0,0,0,0,0}
            };

            //結果
            ResultData pnode = new ResultData();//親ノード
            ResultData p;
            pnode.Strnum = 0;
            pnode.value = "文頭";
            pnode.rerative = 0;
            pnode.parent = null;

            string stTarget = null;//入力された文字列から切り出した文字列
            int min = 0, max = 1;//切り出す範囲
            int stLength = 0;//文字列の長さ
            int difpoint = 0;//次に切り出す文字位置


            //形態素解析
            while(true)
            {
                string str = Console.ReadLine();//標準入力
                if (str == "break")
                {//breakが入力された時終了
                    break;
                }

                stLength = str.Length;
                //パターン1
                while (true)
                {
                    stTarget = str.Substring(min, max);//切り出す
                    if (WordDic.ContainsKey(stTarget))
                    {//keyが存在するかどうか
                        foreach (var n in WordDic[stTarget])
                        {
                            p = new ResultData();
                            p.value = stTarget;
                            p.rerative = n;

                            ResultData.SearchNode(pnode,p,min,max,RerationDic);
                            /*if(RerationDic[q.rerative,n] == 1)
                            {
                                if(q.Strnum == min){
                                    q.children.Add(p);
                                    p.Strnum = q.Strnum + max;
                                    p.parent = q;
                                    q = p;
                                }

                            }*/

                            //Console.WriteLine(stTarget + " ( " + n + " )");//コンソール表示
                        }
                    }
                    else
                    {//登録されていない単語
                        if (difpoint == 0 && max >= 2){
                            difpoint = max + min - 1;
                        }
                        //Console.WriteLine(stTarget+" 登録されていません");
                    }

                    if(max == stLength-min){
                        min = difpoint;
                        max = 0;
                        difpoint = 0;
                    }
                    //Console.WriteLine("min:" + min + "max:" + max + "stLength" + stLength);
                    if(min == 0 && max == 0){
                        Console.WriteLine();
                        ResultData.ShowNode(pnode,part);
                        p = null;
                        pnode.Strnum = 0;
                        pnode.value = "文頭";
                        pnode.rerative = 0;
                        pnode.parent = null;
                        pnode.children.Clear();
                        break;
                    }
                    max++;//一文字増やす
                }

                //パターン2
                //while()
                str = null;
                max = 1;
                min = 0;

            }
        }


    }
    /// <summary>
    /// 結果用クラスツリー
    /// </summary>
    public class ResultData {
        /// <summary>
        /// データ　単語
        /// </summary>
        public string value;
        /// <summary>
        /// データ　品詞
        /// </summary>
        public int rerative;
        /// <summary>
        /// 現ノードまでの文字数
        /// </summary>
        public int Strnum;
        /// <summary>
        /// 親要素
        /// </summary>
        public ResultData parent;
        /// <summary>
        /// 子要素
        /// </summary>
        public List<ResultData> children = new List<ResultData>();
        /// <summary>
        /// Searchs the node.
        /// </summary>
        /// <returns>The node.</returns>
        /// <param name="hoge">ResultDataのインスタンス</param>
        public static void SearchNode(ResultData hoge,ResultData input,int min,int max,int[,] rerationdic)
        {
            if(hoge.children.Count != 0){
                foreach (ResultData i in hoge.children)
                {
                    SearchNode(i, input,min,max,rerationdic);
                }
                if(rerationdic[hoge.rerative, input.rerative] == 1){
                    if (hoge.Strnum == min)
                    {
                        ResultData q = new ResultData();
                        q.value = input.value;
                        q.rerative = input.rerative;
                        q.Strnum = hoge.Strnum + max;
                        q.parent = hoge;
                        hoge.children.Add(q);
                    }
                    
                }
            }else{
                if (rerationdic[hoge.rerative, input.rerative] == 1)
                {
                    if (hoge.Strnum == min)
                    {
                        ResultData q = new ResultData();
                        q.value = input.value;
                        q.rerative = input.rerative;
                        q.Strnum = hoge.Strnum + max;
                        q.parent = hoge;
                        hoge.children.Add(q);

                    }
                }
            }
        }

        public static void ShowNode(ResultData node,string[] part){
            if (node.children.Count != 0)
            {
                Console.WriteLine(node.value + ":" + part[node.rerative]);
                //Console.WriteLine(node.children.Count);
                foreach (ResultData i in node.children)
                {
                    
                    ShowNode(i,part);
                    Console.WriteLine();
                    //Console.WriteLine(node.value + ":" + part[node.rerative]);
                }
            }
            else
            {
                Console.WriteLine(node.value + ":" + part[node.rerative]);
            }

        }
    }

    /// <summary>
    /// キーと複数の値のコレクションを表します
    /// </summary>
    public class MultiDictionary<TKey, TValue>
    {
        private readonly Dictionary<TKey, List<TValue>> mDictionary = new Dictionary<TKey, List<TValue>>();

        /// <summary>
        /// 指定したキーに関連付けられている複数の値を取得または設定します
        /// </summary>
        public List<TValue> this[TKey key]
        {
            get { return mDictionary[key]; }
            set { mDictionary[key] = value; }
        }

        /// <summary>
        /// キーを格納しているコレクションを取得します
        /// </summary>
        public Dictionary<TKey, List<TValue>>.KeyCollection Keys
        {
            get { return mDictionary.Keys; }
        }

        /// <summary>
        /// 複数の値を格納しているコレクションを取得します
        /// </summary>
        public Dictionary<TKey, List<TValue>>.ValueCollection Values
        {
            get { return mDictionary.Values; }
        }

        /// <summary>
        /// 格納されているキーと値のペアの数を取得します
        /// </summary>
        public int Count
        {
            get { return mDictionary.Count; }
        }

        /// <summary>
        /// 指定したキーと値をディクショナリに追加します
        /// </summary>
        public void Add(TKey key, TValue value)
        {
            if (!mDictionary.ContainsKey(key))
            {
                mDictionary.Add(key, new List<TValue>());
            }
            mDictionary[key].Add(value);
        }

        /// <summary>
        /// 指定したキーと複数の値をディクショナリに追加します
        /// </summary>
        public void Add(TKey key, params TValue[] values)
        {
            foreach (var n in values)
            {
                Add(key, n);
            }
        }

        /// <summary>
        /// 指定したキーと複数の値をディクショナリに追加します
        /// </summary>
        public void Add(TKey key, IEnumerable<TValue> values)
        {
            foreach (var n in values)
            {
                Add(key, n);
            }
        }

        /// <summary>
        /// 指定したキーを持つ値を削除します
        /// </summary>
        public bool Remove(TKey key, TValue value)
        {
            return mDictionary[key].Remove(value);
        }

        /// <summary>
        /// 指定したキーを持つ複数の値を削除します
        /// </summary>
        public bool Remove(TKey key)
        {
            return mDictionary.Remove(key);
        }

        /// <summary>
        /// すべてのキーと複数の値を削除します
        /// </summary>
        public void Clear()
        {
            mDictionary.Clear();
        }

        /// <summary>
        /// 指定したキーと値が格納されているかどうかを判断します
        /// </summary>
        public bool Contains(TKey key, TValue value)
        {
            return mDictionary[key].Contains(value);
        }

        /// <summary>
        /// 指定したキーが格納されているかどうかを判断します
        /// </summary>
        public bool ContainsKey(TKey key)
        {
            return mDictionary.ContainsKey(key);
        }

        /// <summary>
        /// 反復処理する列挙子を返します
        /// </summary>
        public IEnumerator<KeyValuePair<TKey, List<TValue>>> GetEnumerator()
        {
            foreach (var n in mDictionary)
            {
                yield return n;
            }
        }
    }

}
